# Import dari flask
from flask import Blueprint,render_template,redirect,request,flash,url_for
from .forms import RegistarationForm,LoginForm

auth = Blueprint('auth',__name__)


@auth.route('/login',methods = ['GET','POST'])
def login():
	form = LoginForm()
	if form.validate_on_submit():
		user = None
		username = form.username.data
		password = form.password.data
		email = form.username.data
		user_by_Username = User.query.filter_by(username=username).first()
		user_by_email = User.query.filter_by(email_address=email).first()

		if user_by_Username:
			user = user_by_Username
		elif user_by_email:
			user = user_by_email

		if user:
			if check_password_hash(user.password,password):
				flash('Logged in succesfully!',category='success')
				login_user(user,duration = timedelta(seconds=1))
				return redirect(url_for('views.profile'))
			else:
				flash('Incorrect password, try again.',category='error')
		else:
			flash("Email does not exist.",category='error')
		
	return render_template('login_page.html',form = form)


@auth.route('/SignUp',methods = ['GET','POST'])
def SignUp():
	form = RegistarationForm()
	if form.validate_on_submit():
		username = form.username.data
		password = form.password.data
		email = form.email.data
		user = User.query.filter_by(username=username).first()
		if username.lower() != 'jordan' and username.lower() != 'charlos':
			if username != "null" or username != None:

			
				if user is None:
					user = User.query.filter_by(email_address=email).first()
					if user is None:	
						new_user = User(username = username,password=generate_password_hash(password,method='sha256'),email_address=email)
						db.session.add(new_user)
						db.session.commit()
						login_user(new_user,duration = timedelta(seconds=1))
						return redirect(url_for('views.profile'))
					else:
						flash('email address already exist',category='error')
				else:
					flash('username already exist',category='error')
			else:
				flash('congratulation you find the bug',category='error')
		else:
			flash('dont use this name',category='error')


				
	return render_template('sign_up.html',form=form)