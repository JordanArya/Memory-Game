from website import db

from datetime import datetime

class Images(db.Model):
	id = db.Column(db.Integer, db.Identity(start = 1, cycle = True), primary_key = True)
	image_file = db.Column(db.String(100), unique = True, nullable = False)
	first_name = db.Column(db.String(20), nullable = False)
	last_name = db.Column(db.String(20), nullable = False)
	relationship = db.Column(db.String(20), nullable = False)