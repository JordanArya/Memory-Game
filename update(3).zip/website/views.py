

# Flask Things
from flask import Blueprint,render_template,request,redirect,url_for,flash,session,jsonify
from flask_login import login_required,current_user


# Data From Other File
from website import app, db
from website.models import Images

# Anything else
import base64
import json
from PIL import Image
from werkzeug.utils import secure_filename
import os
import time

views = Blueprint('views',__name__)


# Home index
@views.route("/")
@views.route("/home")
def home():
	images = Images.query.all()
	image_filename = []
	image_firstname = []
	image_lastname = []
	for image in images:
		image_filename.append(image.image_file)
		image_firstname.append(image.first_name)
		image_lastname.append(image.last_name)
	return render_template('home.html', image_files = image_filename, image_firstnames = image_firstname, image_lastnames = image_lastname, user=current_user)

# About index
@views.route("/about")
def about():
	return render_template('about.html')



@views.route("/upload", methods = ["GET", "POST"])
def upload_draft():
	if request.method == "POST":
		first_name = request.form.get("fname")
		last_name = request.form.get("lname")
		relationship = request.form.get("relation")
		image_file = save_image(request.files["image"])

		image = Images(first_name = first_name, last_name = last_name, relationship = relationship, image_file = image_file)
		db.session.add(image)
		db.session.commit()
		return redirect(url_for("views.home"))

	return render_template('upload_draft.html')

#SAVE IMAGE
def save_image(input_image):
	filename = secure_filename(input_image.filename) 
	input_image.save(os.path.join(app.root_path, "static/Pciture_1", filename)) 

	return filename

@views.route("/choose")
def choose_draft():
	return render_template('choose_draft.html')

@app.route('/postmethod', methods = ['POST'])
def get_post_javascript_data():
    output = request.get_json()
    print(request.args)

    print(type(output[1]))
    print("haloooo")
    return redirect(url_for('views.home'))


	
	




