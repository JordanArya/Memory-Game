from flask import Flask,session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from datetime import timedelta

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///data/data.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


def create_app():
	app.config['SECRET_KEY'] = 'adwad$aidwaik***dadwaddmawdkwa'

	from .views import views
	from .auth import auth


	app.register_blueprint(views,url_prefix='/')
	app.register_blueprint(auth,url_prefix='/')

	return app


	


