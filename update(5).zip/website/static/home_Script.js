let point = 0;
// check_layout()


function NextLevel(self){
		console.log('halo')
		Check_answer(self)
		user_answer = answer.value;
		image = document.getElementById("q-picture");
		level = document.getElementById("level-tag");

		next_level = parseInt(level.innerText);
		if (next_level < Name.length){
			if (user_answer.length != 0){ 
			 	
				 image = document.getElementById("q-picture");
				 level = document.getElementById("level-tag");
				 next_level = parseInt(level.innerText);

				if(point){
				 	 if (next_level < (Name.length)){
				 	 	 image.src = Name[next_level];
				 	 	 level.innerText = next_level+1;
				 	}
				}

				else{
				 	live = document.getElementById('life-tag');
				 	player_live = live.innerText;
					live.innerText = parseInt(player_live)-1;
				 	alert('Jawaban Kamu Salah Coba Ingat Lagi');
				}
				answer.value = null
			}

			else{
				alert('Tolong Isi Jawabannya')
			}
		}

		else{
			alert('Your Score is ' + point)
		}
	}

	


function Check_answer(self){
	let score = 0
	answer = document.getElementById("User-Answer");
	user_answer = answer.value;
	level = document.getElementById("level-tag")
	next_level = parseInt(level.innerText);
	
	const first_name_answer = First_name[next_level-1].match(/\w+/g)
	const last_name_answer = Last_name[next_level-1].match(/\w+/g)
	const also_known_answer = Also_known[next_level-1].match(/\w+/g)
	const user_answers = user_answer.match(/\w+/g)
	
	if(First_name[next_level-1] == (user_answer) || Last_name[next_level-1] == (user_answer) || Also_known[next_level-1] == (user_answer)){
		score = 100
		point += 100
	}

	


	if(score == 0){
		for (var y = 0; y < user_answers.length; y ++){
			for (var i = 0; i < first_name_answer.length; i ++){
				if (first_name_answer[i].includes(user_answers[y])){
					score = user_answers[i].length/first_name_answer[i].length * 100;
					point += score;
					break;
				}
			}
		}
	}

	if(score == 0){
		for (var y = 0; y < user_answers.length; y ++){
			for (var i = 0; i < last_name_answer.length; i ++){
				if (last_name_answer[i].includes(user_answers[y])){
					score = user_answers[i].length/last_name_answer[i].length * 100;
					point += score
					break;
				}
			}
		}
	}

	if(score == 0){
		for (var y = 0; y < user_answers.length; y ++){
			for (var i = 0; i < also_known_answer.length; i ++){
				if (also_known_answer[i].includes(user_answers[y])){
					score += user_answers[i].length/also_known_answer[i].length * 100;
					console.log(score)
					point +=  score;
					break;
				}
			}
		}
	}

alert(point)

}

function Start_from_zero(self){
	level = document.getElementById("level-tag").innerText = 1
	live = document.getElementById('life-tag').innerText = 5
	image = document.getElementById("q-picture").src = Name[0]
}

// const Name=['gambar1.jpg','gambar2.jpg','gambar3.jpg','gambar4.jpg','gambar5.jpg','gambar6.jpg']
document.getElementById('Max-level').innerText = '/ ' + (Name.length).toString()


var answer = document.getElementById("User-Answer");
answer.addEventListener("keydown", function(event) {
if (event.key === "Enter") {
	NextLevel(this)
}

});





