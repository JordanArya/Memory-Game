

var finish = false;
let point = 0;
// check_layout()
var relationship_score = {"keluarga inti":0,"keluarga jauh":0,"teman jauh":0,'teman kerja':0}
var total_score = {"keluarga inti":0,"keluarga jauh":0,"teman jauh":0,'teman kerja':0}





function NextLevel(self){
		user_answer = answer.value;
		image = document.getElementById("q-picture");
		level = document.getElementById("level-tag");
		next_level = parseInt(level.innerText);
		
		if (! finish){
			Check_answer(self)
		}

		

		
		if (next_level < Name.length){
			if (user_answer.length != 0){ 
			 	
				 image = document.getElementById("q-picture");
				 level = document.getElementById("level-tag");
				 next_level = parseInt(level.innerText);

				
				 	if (next_level < (Name.length)){
				  	 image.src = Name[next_level];
				 	 level.innerText = next_level+1;
				 	}
			
				answer.value = null
			}

			else{
				alert('Tolong Isi Jawabannya')
			}
		}

		else{
			alert('Your Score is ' + point)
		}
	}

	


function Check_answer(self){
	
	let score = 0
	answer = document.getElementById("User-Answer");
	user_answer = answer.value;
	level = document.getElementById("level-tag")
	next_level = parseInt(level.innerText);
	
	const first_name_answer = First_name[next_level-1].match(/\w+/g)
	const last_name_answer = Last_name[next_level-1].match(/\w+/g)
	// const also_known_answer = Also_known[next_level-1].match(/\w+/g)
	const user_answers = user_answer.match(/\w+/g)

	
	if(First_name[next_level-1] == (user_answer) || Last_name[next_level-1] == (user_answer)){
		if(relationship_score[relation[next_level-1]]){
			relationship_score[relation[next_level-1]] += 1
		} 

		else{
			relationship_score[relation[next_level-1]] = 1
		}
		score = 100
		point += 100

	}

	


	if(score == 0){
		for (var y = 0; y < user_answers.length; y ++){
			for (var i = 0; i < first_name_answer.length; i ++){
				if (first_name_answer[i].includes(user_answers[y])){
					if(relationship_score[relation[next_level-1]]){
						relationship_score[relation[next_level-1]] += 1
					} 

					else{
						relationship_score[relation[next_level-1]] = 1
					}
					score = user_answers[i].length/first_name_answer[i].length * 100;
					point += score;
					break;
				}
			}
		}
	}

	if(score == 0){
		for (var y = 0; y < user_answers.length; y ++){
			for (var i = 0; i < last_name_answer.length; i ++){
				if (last_name_answer[i].includes(user_answers[y])){
					if(relationship_score[relation[next_level-1]]){
						relationship_score[relation[next_level-1]] += 1
					} 

					else{
						relationship_score[relation[next_level-1]] = 1
					}
					score = user_answers[i].length/last_name_answer[i].length * 100;
					point += score
					break;
				}
			}
		}
	}
	
	if(score  > 0 && next_level == Name.length){
		finish = true
		send_Data()
	}


	total_score[relation[next_level-1]] += 1
	
	

alert(point)

}

function Start_from_zero(self){
	level = document.getElementById("level-tag").innerText = 1
	image = document.getElementById("q-picture").src = Name[0]
}

function send_Data(){
	// var datas = ['anak','satu','dua']
	var data_keluarga_dekat = relationship_score['keluarga intit']
	var data_keluarga_jauh = relationship_score['keluarga jauh']
	var data_teman_dekat = relationship_score['teman dekat']
	var data_teman_jauh = relationship_score['teman jauh']
	

	$.ajax({
	    url: '/upload_score',
	    type: "POST",
	    dataType: "json",
	  	data: {
	  		score: JSON.stringify(point),
	  		keluarga_dekat: JSON.stringify(relationship_score['keluarga inti']),
	  		keluarga_jauh: JSON.stringify(relationship_score['keluarga jauh']),
	  		teman_dekat: JSON.stringify(relationship_score['teman jauh']),
	  		teman_kerja: JSON.stringify(relationship_score['teman kerja'])
	  	}
  	})

  	window.location.href = "/redirect_graph"
}


// const Name=['gambar1.jpg','gambar2.jpg','gambar3.jpg','gambar4.jpg','gambar5.jpg','gambar6.jpg']
document.getElementById('Max-level').innerText = '/ ' + (First_name.length).toString()


var answer = document.getElementById("User-Answer");
answer.addEventListener("keydown", function(event) {
if (event.key === "Enter") {
	NextLevel(this)
}

});





