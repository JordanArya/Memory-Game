var data_keluarga_jauh = [12,1,2,1,21,13];
var data_keluarga_dekat = [121,121,2,1,2,12,];
var data_teman_dekat = [1,2,1,21,2,1,2,1,];
var data_teman_jauh = [12,12,1,2,1,21];

const ctx = document.getElementById('myCharts').getContext('2d');
const myChart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['Keluarga Inti', 'Keluarga Jauh', 'Teman Dekat', 'Teman Kerja'],
        datasets: [{
            data: [12, 19, 3, 5],
            backgroundColor: [
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 206, 86)',
                'rgb(75, 192, 192)',
                'rgb(153, 102, 255)',
                'rgb(255, 159, 64)'
            ],
         
            borderWidth: 5,
            hoverOffset: 20,

        }]
    },
    options: {
       position: 'center',
       responsive: true,
       maintainAspectRatio: true,
       intersect: true,

       onClick: (e) => {
        const data = myChart.data.labels
        const points = myChart.getElementsAtEventForMode(e, 'nearest', { intersect: true }, true);
        if (points.length){
        const firstPoint = points[0]
        console.log(firstPoint.index)
        if (firstPoint.index == 0){
            update_chart_2(data_keluarga_dekat,data[0])
        }
         else if (firstPoint.index == 1){
            update_chart_2(data_keluarga_jauh,data[1])
        }
          else if (firstPoint.index == 2){
            update_chart_2(data_teman_dekat,data[2])
        }
          else if (firstPoint.index == 3){
            update_chart_2(data_teman_jauh,data[3])
        }
        // const value = myChart.data.datasets[firstPoint.datasetIndex];
        // console.log(value)
    }
}}});



const ctxs = document.getElementById('Spesific-data').getContext('2d');
const myCharts = new Chart(ctxs, {
    type: 'bar',
    data: {
        labels: ['Percobaan 1','Percobaan 2','Percobaan 3','Percobaan 4','Percobaan 5','Percobaan 6'],
        datasets: [{
            label: '',
            data: [0,0,0,0,0,0],
            backgroundColor: [
                'rgb(255, 99, 132)',
                'rgb(54, 162, 235)',
                'rgb(255, 206, 86)',
                'rgb(75, 192, 192)',
                'rgb(153, 102, 255)',
                'rgb(255, 159, 64)'
            ],
         
            borderWidth: 5,
            hoverOffset: 20,

        }]
    }
   }
)

function update_chart_2(datas,label){
    myCharts.data.datasets[0].data = datas
    myCharts.data.datasets[0].label = label
    myCharts.update()
}







